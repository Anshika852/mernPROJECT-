# AI-Image-Generator
A Web app which generate Images of user-defined prompt. OpenAI's API is used to generate Images

## Functionality
- User can see what others AI generated images
- Users can create their own AI generated images
- Users can download others AI generated images
- User Authentication and Authorization
- Users can Like others Posts
- Pasgination

## Preview

### Homepage
![Screenshot (215)](https://user-images.githubusercontent.com/83984612/218133171-fd7b1a6d-5250-4efe-bd58-69fb9def161b.png)

### CreatePage
![Screenshot (216)](https://user-images.githubusercontent.com/83984612/218241257-7e20c88b-ffb0-4b41-8e9a-ffdec7ca087e.png)

### LoginPage
![Screenshot (217)](https://user-images.githubusercontent.com/83984612/221364522-bef55e4a-d670-4e36-9b1f-5c36e4828550.png)

### SignupPage
![Screenshot (218)](https://user-images.githubusercontent.com/83984612/221364555-e94798e5-4ddf-4fe7-beac-296dad0f4667.png)
