import download from './download.png';
import logo from './logo.svg';
import preview from './preview.png';
import loader from './Rolling-3s-91px.svg'

export {
  download,
  logo,
  preview,
  loader,
};
